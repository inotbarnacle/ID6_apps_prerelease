# iDriveDeck v0.7.18 layouts for small panels

`layouts/<WxH>/<App>.xml` (and `<App>_ALL_Images.zip`) replace the app's own on an 800x480 or 960x480 panel,
for the standard menus and the full-screen ones. 1280x480, 1440x540 and 1920x720 use the apps' own files.
