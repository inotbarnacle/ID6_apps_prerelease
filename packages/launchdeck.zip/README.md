# LaunchDeck

## Package update

LaunchDeck uses connector ID 120. OPTIONS selects 0–60 or 60–130 mph, or 0–100 or 100–200 km/h. It saves three results for each mode. The hundredths display is interpolated from OBD speed samples.

Install the selected app folders under /var/opt/hmi/data/ID5/Plugins on the HMI node. Verify compatibility and set executable permissions on the -qnx worker before a parked restart. A verified IPv4 address in /var/opt/hmi/data/ID5/gateway-ip.txt overrides per-app settings. Setup instructions are in the repository AgentReadMe.
