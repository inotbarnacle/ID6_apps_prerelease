# iDriveDeck v0.7.18 full-screen apps

From the iDriveDeck v0.7.18 desktop installer (inotbarnacle/iDriveDeck). `ID6LibraryLab` is the shared
full-screen engine and its workers (it starts with iDrive); each `ID6Full*` folder is one full-screen menu
under My Vehicle. The installer writes the panel size into `ID6LibraryLab/panel.txt` (`1280x480`) and
`ID6LibraryLab/screen-size.txt` (`1280 480`). Panels 800x480 and 960x480 take the XMLs of `layouts.zip`.
