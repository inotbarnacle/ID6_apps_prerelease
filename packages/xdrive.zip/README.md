# xDrive Control

See the [compatibility matrix](https://github.com/inotbarnacle/ID6_apps_prerelease/blob/main/source/docs/COMPATIBILITY.md).

## Package update

F-series DSC_25 (0F1860) requires LMV 0F1480, a running engine, transmission in Park, and zero speed. DSC_25 expects the EGS Park response 00 01 with the engine running. Supported G-series DSCs require the engine off and the EGS Park response 00 06. On unsupported DSCs, Refresh status can report the LMV and VIP module indexes. The feature remains experimental.

Install the selected app folders under /var/opt/hmi/data/ID5/Plugins on the HMI node. Verify compatibility and set executable permissions on the -qnx worker before a parked restart. A verified IPv4 address in /var/opt/hmi/data/ID5/gateway-ip.txt overrides per-app settings. Setup instructions are in the repository AgentReadMe.
